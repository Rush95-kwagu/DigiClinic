
<?php $__env->startSection('user_content'); ?>
<?php $__env->startSection('title'); ?>
Repertoire patient
<?php $__env->stopSection(); ?>
<?php  
 $user_role_id=Session::get('user_role_id');
 $user_id=Session::get('user_id');
 $centre_id=Session::get('centre_id');
?>

          <!-- App body starts -->
          <div class="app-body">

            <!-- Row starts -->
            <div class="row gx-3">
              <div class="col-sm-12">
                <div class="card">
                  <div class="card-header">
                    <h5 class="card-title">Ajouter une nouvelle prestation</h5>
                  </div>
                  <div class="col-sm-12">
                    <div class="d-flex gap-2 justify-content-end">
                      <a href="<?php echo e(url('all-prestations')); ?>" class="btn btn-success">
                        Voir la liste
                      </a>
                      
                    </div>
                  </div>
                  <div class="card-body">
                    
                 <script>
                        document.addEventListener('DOMContentLoaded', function () {
                            <?php if(session('PersonnalAdded')): ?>
                                Swal.fire({
                                    title: 'Ajouté !',
                                    text: "<?php echo e(session('PersonnalAdded')); ?>",
                                    icon: 'success',
                                    confirmButtonText: 'OK',
                                    timer: 5000 
                                    
                                });
                            <?php endif; ?>
                        });
            </script>
                  

                    <!-- Row starts -->
                    <div class="row gx-3">
                      <div class="col-xxl-3 col-lg-4 col-sm-6">
                        <div class="mb-3">
                          <form action="<?php echo e(route('add.prestation')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="user_role_id" value="<?php echo e(Session::get('user_role_id')); ?>">
                            <input type="hidden" name="centre_id" value="<?php echo e(Session::get('centre_id')); ?>">
                          <label class="form-label" for="a1">Nom de la prestation</label>
                          <input type="text" class="form-control" name="nom_prestation" id="a1" placeholder="Enter Room Number">
                        </div>
                      </div>
                      <div class="col-xxl-3 col-lg-4 col-sm-6">
                        <div class="mb-3">
                          <label class="form-label" for="a2">Coût de la prestation</label>
                          <input type="number" class="form-control" name="prix_prestation" id="a2" placeholder="Enter Floor Number">
                                                  </div>
                      </div>
                      
                      
                      
                      <div class="col-sm-12">
                        <div class="d-flex gap-2 justify-content-end">
                          <a href="available-rooms.html" class="btn btn-outline-secondary">
                            Annuler
                          </a>
                          <button type="submit" class="btn btn-primary">
                            Valider les informations
                          </button>
                        </div>
                      </div>
                    </div>
                    <!-- Row ends -->
                  </form>
                  </div>
                </div>
              </div>
            </div>
            <!-- Row ends -->

          </div>
          <!-- App body ends -->

       <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP ELITEBOOK X360\Downloads\digiclinic\resources\views/prise_enc/add_prestation_form.blade.php ENDPATH**/ ?>