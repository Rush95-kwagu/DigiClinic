<?php $__env->startSection('add service content'); ?>

<?php
$user_role_id=Session::get('user_role_id');
$user_id=Session::get('user_id');
  
?>


          <!-- App body starts -->
          <div class="app-body">

            <!-- Row starts -->
            <div class="row gx-3">
              <div class="col-sm-12">
                <div class="card">
                  <div class="card-header">
                    <h5 class="card-title">Informations relatives au nouveau service</h5>
                  </div>
                  <div class="card-body">

                    <!-- Row starts -->
                    <div class="row gx-3">

                   <?php if(session()->has('ServiceCreated')): ?>
                   <div class="alert alert-success" role="alert">
                    <h4 class="alert-heading">Service Créé</h4>
                    <p><?php echo e(session()->get('DepartementCreated')); ?></p>
                    <hr />
                    <p class="mb-0"><a href="<?php echo e(route('services.index')); ?>">Retour à la liste</a> </p>
                   </div>
                </div>

                   <?php endif; ?>
                  

                        <?php if(!session()->has('ServiceCreated')): ?>
                        <div class="col-xxl-3 col-lg-4 col-sm-6">
                          <form action="<?php echo e(route('entities.store')); ?>" method="POST">
                              <?php echo csrf_field(); ?>
                        <div class="mb-3">
                          <label class="form-label" for="specialite">Spécialité <span
                            class="text-danger">*</span></label>
                          <input type="text" class="form-control" id="a1" name="specialite" placeholder="Spécialité" required>
                        </div>
                      </div>
                      <div class="col-xxl-3 col-lg-4 col-sm-6">
                        <div class="mb-3">
                          <label class="form-label" for="service">Service <span
                            class="text-danger">*</span></label>
                          <input type="text" class="form-control" id="service" name="service" placeholder="Service" required>
                        </div>
                      </div>
                      <div class="col-xxl-3 col-lg-4 col-sm-6">
                        <div class="mb-3">
                          <label class="form-label" for="telephone">Téléphone <span
                            class="text-danger">*</span></label>
                          <input type="text" class="form-control" id="telephone" name="telephone" placeholder="Nom du service" required>
                        </div>
                      </div>
                      <div class="col-xxl-3 col-lg-4 col-sm-6">
                        <div class="mb-3">
                          <label class="form-label" for="email">Email <span
                            class="text-danger">*</span></label>
                          <input type="email" class="form-control" id="email" name="email" placeholder="Email du service" required>
                        </div>
                      </div>
                   

                      <div class="col-xxl-3 col-lg-4 col-sm-6">
                        <div class="mb-3">
                          <label class="form-label" for="status">Fonctionnel <span
                              class="text-danger">*</span></label>
                          <div class="m-0">
                            <div class="form-check form-check-inline">
                              <input class="form-check-input" type="radio" name="status" id="status"
                               >
                              <label class="form-check-label" for="status">Oui</label>
                            </div>
                            <div class="form-check form-check-inline">
                              <input class="form-check-input" type="radio" name="status" id="status"
                                >
                              <label class="form-check-label" for="status">Non</label>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-xxl-3 col-lg-4 col-sm-6">
                        <div class="mb-3">
                          <label class="form-label" for="chef_service">Chef service<span
                            class="text-danger">*</span></label>
                          <select class="form-select"  id="personnel_id" name="chef_service" required>
                            <?php
                                $personnel = DB::table('personnel')->get();
                            ?>
                            <option value="">---Nommer un chef---</option>
                                <?php $__currentLoopData = $personnel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chef_serv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($chef_serv->id); ?>">Dr. <?php echo e($chef_serv->nom); ?> <?php echo e($chef_serv->prenom); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>
                      </div>
                      

                      
                      <div class="col-sm-12">
                        <div class="d-flex gap-2 justify-content-end">
                          <a href="departments-list.html" class="btn btn-outline-secondary">
                            Annuler
                          </a>
                          <button type="submit" class="btn btn-primary">
                            Créer le service
                          </button>
                        </div>
                      </div>
                    </div>
                    <!-- Row ends -->
                </form>

                        <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
            <!-- Row ends -->

          </div>
          <!-- App body ends -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ADMIN\Downloads\digiclinic\resources\views/service/add-service.blade.php ENDPATH**/ ?>