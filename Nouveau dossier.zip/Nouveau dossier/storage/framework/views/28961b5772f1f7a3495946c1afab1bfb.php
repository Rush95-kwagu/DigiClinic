
<?php $__env->startSection('user_content'); ?>
<?php $__env->startSection('title'); ?>
Repertoire patient
<?php $__env->stopSection(); ?>
<?php  
 $user_role_id=Session::get('user_role_id');
 $user_id=Session::get('user_id');
 $centre_id=Session::get('centre_id');
?>

          <!-- App body starts -->
          <div class="app-body">

            <!-- Row starts -->
            <div class="row gx-3">
              <div class="col-sm-12">
                <div class="card">
                  <div class="card-header d-flex align-items-center justify-content-between">
                    <h5 class="card-title">Répertoire des prestations</h5>
                    <a href="<?php echo e(url('add-form')); ?>" class="btn btn-primary ms-auto">Ajouter une prestation</a>
                  </div>
                  <div class="card-body">

                    <!-- Table starts -->
                    <div class="table-responsive">
                      <table id="example" class="table truncate m-0 align-middle">
                        <thead>
                          <tr>
                            <th>N°.</th>
                            <th>Type de prestation</th>
                            <th>Coût de la prestation</th>
                           <th>Actions</th>
                          </tr>
                        </thead>
                        <?php
                             $centre_id=Session::get('centre_id');
                             $prestation=DB::table('tbl_prestation')->get();
                        ?>
                        <tbody>
                          <?php $__currentLoopData = $prestation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_prestation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              
                         
                          <tr>
                            <td><?php echo e($all_prestation->prestation_id); ?> °)</td>
                         
                            <td><?php echo e($all_prestation->nom_prestation); ?></td>
                            <td><?php echo e($all_prestation->prix_prestation); ?>  FCFA</td>
                            <?php if($user_role_id == 11): ?>
                                
                            <td>
                              <div class="d-inline-flex gap-1">
                                <button class="btn btn-outline-danger btn-sm" data-bs-toggle="modal"
                                  data-bs-target="#delRow">
                                  <i class="ri-delete-bin-line"></i>
                                </button>
                                <a href="edit-patient.html" class="btn btn-outline-success btn-sm"
                                  data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Modifier la prestation">
                                  <i class="ri-edit-box-line"></i>
                                </a>
                                </div>
                            </td>
                            <?php endif; ?>

                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                    </div>
                    <!-- Table ends -->

                    <!-- Modal Delete Row -->
                    <div class="modal fade" id="delRow" tabindex="-1" aria-labelledby="delRowLabel" aria-hidden="true">
                      <div class="modal-dialog modal-sm">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="delRowLabel">
                              Confirm
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                          </div>
                          <div class="modal-body">
                            Are you sure you want to delete the patient?
                          </div>
                          <div class="modal-footer">
                            <div class="d-flex justify-content-end gap-2">
                              <button class="btn btn-outline-secondary" data-bs-dismiss="modal"
                                aria-label="Close">No</button>
                              <button class="btn btn-danger" data-bs-dismiss="modal" aria-label="Close">Yes</button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                  </div>
                </div>
              </div>
            </div>
            <!-- Row ends -->

          </div>
          <!-- App body ends -->
          <?php $__env->startSection('Datatable'); ?>
    <script>
      $(document).ready(function() {
      $("#example").DataTable();
     
    });
      $("select").change(function(){
      if(confirm('Cliquez OK pour envoyer le patient vers le spécialiste')){
          {this.form.submit()} 
      }
      else $("select option:selected").prop("selected", false);
    });
    </script>
    
    <?php $__env->stopSection(); ?>

          <?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP ELITEBOOK X360\Downloads\digiclinic\resources\views/prise_enc/all_prestations.blade.php ENDPATH**/ ?>