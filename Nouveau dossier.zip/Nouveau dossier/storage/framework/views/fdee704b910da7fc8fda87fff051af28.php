<?php $__env->startSection('user_content'); ?>
<?php  
 $user_role_id=Session::get('user_role_id');
 $user_id=Session::get('user_id');
?>

<!-- App body starts -->
          <div class="app-body">

            <!-- Row starts -->
            <div class="row gx-3">
               <div class="col-sm-12">
                <div class="card mb-3">
                  <div class="card-header">
                    <h5 class="card-title">Gestion des analyses</h5>
                  </div>
                  <div class="card-body">
                     <!-- <a href="<?php echo e(URL::to('enregistrer-prise-en-charge')); ?>" class="btn btn-primary btn-lg">
                        Enregistrer une nouvelle prise en charge
                      </a> -->
                    <div class="custom-tabs-container">
                      <ul class="nav nav-tabs justify-content-center" id="customTab4" role="tablist">
                        <li class="nav-item" role="presentation">
                          <a class="nav-link active" id="tab-oneAAA" data-bs-toggle="tab" href="#oneAAA" role="tab"
                            aria-controls="oneAAA" aria-selected="true">Analyses en attente</a>
                        </li>
                       
                        <li class="nav-item" role="presentation">
                          <a class="nav-link" id="tab-twoAAA" data-bs-toggle="tab" href="#twoAAA" role="tab"
                            aria-controls="twoAAA" aria-selected="false">Analyses traités</a>
                        </li>
                        
                      </ul>
                      <div class="tab-content" id="customTabContent">
                        <div class="tab-pane fade show active" id="oneAAA" role="tabpanel">
                          <!-- Row starts -->
                          <div class="row gx-3">
                             <div class="col-sm-12">
                                <div class="card mb-3">
                                  <div class="card-header">
                                    <h5 class="card-title">Analyses non traités</h5>
                                  </div>
                                  <div class="card-body">
                                    <div class="">
                                      <div class="table-responsive">
                                        <table class="table truncate align-middle" id="example">
                                          <thead>
                                            <tr>
                                              <th width="30px">&nbsp;</th>
                                              <th width="60px">Client</th>
                                              <th width="100px">Analyse </th>
                                              <th width="100px">Numero</th>
                                              <th width="100px">Adresse</th>
                                          
                                              <th width="100px">Actions</th>
                                            </tr>
                                          </thead>
                                          <tbody>
                                           <?php $__currentLoopData = $all_analyse_nt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_prisenc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                            <tr>
                                              <td>
                                                <a href="#" class="me-1 icon-box sm bg-light rounded-circle">
                                                <?php if($v_prisenc->sexe_patient == 'F'): ?>
                                                <img style="width:30px; height:30px;" src="<?php echo e(asset('frontend/F.png')); ?>" alt="sexe')}}" class="rounded-circle img-3x">
                                                <?php else: ?>
                                                <img style="width:30px; height:30px;" src="<?php echo e(asset('frontend/M.png')); ?>" alt="sexe" class="rounded-circle img-3x">
                                                <?php endif; ?>
                                                </a>
                                              </td>
                                              <td>
                                                <?php echo e($v_prisenc->prenom_patient); ?>

                                                <?php echo e($v_prisenc->nom_patient); ?>

                                              </td>
                                              <td><h4><span class="badge bg-danger"><?php echo e($v_prisenc->analyse); ?><?php echo e($v_prisenc->libelle_analyse); ?></span></h4></td>
                                              <td><?php echo e($v_prisenc->telephone); ?></td>
                                              <td><?php echo e($v_prisenc->adresse); ?></td>
                                                                                            
                                              <td>
                                              
                                              <a title="Dossier medial du patient" class="btn btn-outline-success" href="<?php echo e(URL::to('traitement-analyse/'.$v_prisenc->id_analyse.'/'.$v_prisenc->patient_id)); ?>">
                                              <i class="ri-file-edit-fill"></i></a>                    
                                              </td>
                                            </tr>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </tbody>
                                        </table>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                          </div>
                          <!-- Row ends -->
                        </div>




                       


                        <div class="tab-pane fade" id="twoAAA" role="tabpanel">
                          <!-- Row starts -->
                          <div class="row gx-3">
                          <div class="col-sm-12">
                            <div class="card mb-3">
                              <div class="card-header">
                                <h5 class="card-title">Analyses traités</h5>
                              </div>
                              <div class="card-body">
                                <div class="table-outer">
                                  <div class="table-responsive">
                                    <table class="table table-striped truncate m-0">
                                      <thead>
                                        <tr>
                                          <th></th>
                                          <th>Client</th>
                                          <th>Analyse</th>
                                          <th>Contact</th>
                                          <th>Date</th>
                                          <th></th>
                                          
                                        </tr>
                                      </thead>
                                      <tbody>
                                      <?php $__currentLoopData = $all_analyse_t; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_consult): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                                        <tr>
                                          <td>
                                          </td>
                                          <td><?php echo e($v_consult->nom_patient); ?>

                                          <?php echo e($v_consult->prenom_patient); ?></td>
                                          <td><?php echo e($v_prisenc->analyse); ?><?php echo e($v_prisenc->libelle_analyse); ?></td>
                                          <td><?php echo e($v_prisenc->telephone); ?></td>
                                          <td>
                                            <?php echo e($v_prisenc->created_at); ?>

                                          </td>
                                          
                                          <td>
                                              
                                              <a title="Dossier medial du patient" class="btn btn-outline-success" href="<?php echo e(URL::to('traitement-analyse/'.$v_consult->id_analyse.'/'.$v_consult->patient_id)); ?>">
                                              <i class="ri-file-edit-fill"></i></a>                    
                                              </td>
                                        <?php ?>
                                        </tr>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      </tbody>
                                    </table>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          </div>
                          <!-- Row ends -->
                        </div>
                        
                      </div>
                    </div>
                  </div>
                </div>
              </div>





              
              
              
            
              
            
              
            
            </div>
            <!-- Row ends -->

          </div>
          <!-- App body ends -->

          
<?php echo $__env->make('sweetalert::alert', ['cdn' => "https://cdn.jsdelivr.net/npm/sweetalert2@9"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('Datatable'); ?>
    <script>
      $(document).ready(function() {
      $("#example").DataTable();
    });
      $("select").change(function(){
      if(confirm('Cliquez OK pour envoyer le patient vers le spécialiste')){
          {this.form.submit()} 
      }
      else $("select option:selected").prop("selected", false);
    });
    </script>
    </script>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ADMIN\Downloads\digiclinic\resources\views/Analys/gestion_analyse.blade.php ENDPATH**/ ?>