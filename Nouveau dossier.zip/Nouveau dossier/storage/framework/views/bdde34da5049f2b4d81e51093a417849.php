<?php $__env->startSection('service content'); ?>
<?php  
 $user_role_id=Session::get('user_role_id');
 $user_id=Session::get('user_id');
?>


          <!-- App body starts -->
          <div class="app-body">

            <!-- Row starts -->
            <div class="row gx-3">
              <div class="col-sm-6">
                <div class="card mb-3">
                  <div class="card-header">
                    <h5 class="card-title">Données relatives aux services</h5>
                  </div>
                  <div class="card-body">

                    <div class="chart-height-lg">
                      <div id="total-department" class="auto-align-graph"></div>
                    </div>

                  </div>
                </div>
              </div>
              <div class="col-sm-6">
                <div class="card mb-3">
                  <div class="card-header">
                    <h5 class="card-title">Données relatives aux employés </h5>
                  </div>
                  <div class="card-body">

                    <div class="chart-height-lg">
                      <div id="employees" class="auto-align-graph"></div>
                    </div>

                  </div>
                </div>
              </div>
              <div class="col-sm-12">
                <div class="card">
                  <div class="card-header d-flex align-items-center justify-content-between">
                    <h5 class="card-title">Répertoire des services</h5>

                    <a href="<?php echo e(route('services.create')); ?>" class="btn btn-primary ms-auto">Créer un nouveau service</a>
                  </div>
                  <div class="card-body">
                    <?php if(session()->has('ServiceDeleted')): ?>
                    <div class="alert alert-success" role="alert">
                    <?php echo e(session()->get('ServiceDeleted')); ?>

                </div>

                   <?php endif; ?>

                    <!-- Table starts -->
                    <div class="table-responsive">
                      <table id="basicExample" class="table m-0 align-middle">
                        <thead>
                          <tr>
                            <th>#</th>
                            <th>Service</th>
                            
                            <th>Chef service</th>
                            <th>Liste des médécins</th>
                            <th>Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tbody>
                          <?php
                            
                             $all_services = DB::table('services')
                                          ->join('personnel', 'services.chef_service','=','personnel.id')
                                          ->select('services.*','personnel.nom as chef_service_nom','personnel.prenom as chef_service_prenom')
                                          ->get();             

                          ?>
                            <?php $__currentLoopData = $all_services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                          <tr>
                            <td><?php echo e($service->id); ?></td>
                            <td><?php echo e($service->service); ?></td>
                            
                            <td>
                              <img src="<?php echo e(asset('frontend/images/user.png')); ?>" class="img-shadow img-2x rounded-5 me-1"
                                alt="Doctors Admin Template">
                             
                         
                           <a href="<?php echo e(route('entitie.directeur.show',['id' => $service->chef_service,
                            'nom' => $service->chef_service_nom, 
                            'prenom' => $service->chef_service_prenom])); ?>">  
                            Dr. <?php echo e($service->chef_service_nom); ?> <?php echo e($service->chef_service_prenom); ?></a> 

                            </td>
                            <td>
                              <div class="stacked-images">
                                <img src="<?php echo e(asset('frontend/F.png')); ?>" alt="Medical Dashboard">
                                <img src="<?php echo e(asset('frontend/M.png')); ?>" alt="Medical Dashboard">
                                <img src="<?php echo e(asset('frontend/F.png')); ?>" alt="Medical Dashboard">
                                <?php
                                    $doctor = DB::table('')
                                ?>
                                <span class="plus bg-primary">+5</span>
                              </div>
                            </td>
                            <td>
                              <div class="d-inline-flex gap-1">
                                
                                <button class="btn btn-outline-danger btn-sm" data-bs-toggle="modal"
                                  data-bs-target="#delRow">
                                  <i class="ri-delete-bin-line"></i>
                                </button>
                                <a href="<?php echo e(route('services.edit',$service->id)); ?>" class="btn btn-outline-success btn-sm rounded-5"
                                  data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Modifier les informartions du service">
                                  <i class="ri-edit-box-line"></i>
                                </a>
                              </div>
                            </td>
                          </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                    </div>
                    <!-- Table ends -->

                    <!-- Modal Delete Row -->
                    <div class="modal fade" id="delRow" tabindex="-1" aria-labelledby="delRowLabel" aria-hidden="true">
                      <div class="modal-dialog modal-sm">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="delRowLabel">
                              Confirmation
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                          </div>
                          <div class="modal-body">
                            Voulez-vous vraiment supprimer ces informations ?
                          </div>
                          <div class="modal-footer">
                            <div class="d-flex justify-content-end gap-2">
                              <a href="#" class="btn btn-secondary" data-bs-dismiss="modal"
                                aria-label="Close">Non</a>
                                  <form action="<?php echo e(route('services.destroy',$service->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>

                                            <button type="submit" class="btn btn-danger" data-bs-dismiss="modal"
                                            aria-label="Close">Oui</button>
                                        </form>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                  </div>
                </div>
              </div>
            </div>
            <!-- Row ends -->

          </div>
          <!-- App body ends -->

       <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP ELITEBOOK X360\Downloads\digiclinic\resources\views/Service/services-list.blade.php ENDPATH**/ ?>