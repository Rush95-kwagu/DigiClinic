<!DOCTYPE html>
<html lang="fr">

  <head>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title'); ?>| DigiClinic</title>

    <!-- Meta -->
    <meta name="description" content="Marketplace for Bootstrap Admin Dashboards">
    <meta name="author" content="Bootstrap Gallery">
    <link rel="canonical" href="https://www.bootstrap.gallery/">
    <meta property="og:url" content="https://www.bootstrap.gallery">
    <meta property="og:title" content="Admin Templates - Dashboard Templates | Bootstrap Gallery">
    <meta property="og:description" content="Marketplace for Bootstrap Admin Dashboards">
    <meta property="og:type" content="Website">
    <meta property="og:site_name" content="Bootstrap Gallery">

    <!-- SweetAlert DataTables.js -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.10.1/dist/sweetalert2.min.css">
    <link href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css" rel="stylesheet">

    <link href="https://cdnjs.cloudflare.com/ajax/libs/slim-select/1.23.0/slimselect.min.css" rel="stylesheet">


    <link rel="shortcut icon" href="<?php echo e(asset('/frontend/images/favicon.svg')); ?>">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('/frontend/fonts/remix/remixicon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/frontend/css/main.min.css')); ?>">

    <!-- *************
    ************ Vendor Css Files *************
  ************ -->

    <!-- Scrollbar CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('/frontend/vendor/overlay-scroll/OverlayScrollbars.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/frontend/vendor/dropzone/dropzone.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/frontend/vendor/quill/quill.core.css')); ?>">
  </head>

  <body>

    <!-- Loading starts -->
    <div id="loading-wrapper">
      <div class='spin-wrapper'>
        <div class='spin'>
          <div class='inner'></div>
        </div>
        <div class='spin'>
          <div class='inner'></div>
        </div>
        <div class='spin'>
          <div class='inner'></div>
        </div>
        <div class='spin'>
          <div class='inner'></div>
        </div>
        <div class='spin'>
          <div class='inner'></div>
        </div>
        <div class='spin'>
          <div class='inner'></div>
        </div>
      </div>
    </div>
    <!-- Loading ends -->

    <!-- Page wrapper starts -->
    <div class="page-wrapper">

      <!-- App header starts -->
      <div class="app-header d-flex align-items-center">

        <!-- Toggle buttons starts -->
        <div class="d-flex">
          <button class="toggle-sidebar">
            <i class="ri-menu-line"></i>
          </button>
          <button class="pin-sidebar">
            <i class="ri-menu-line"></i>
          </button>
        </div>
        <!-- Toggle buttons ends -->

        <!-- App brand starts -->
        <div class="app-brand ms-3">
          <a href="index.html" class="d-lg-block d-none">
            <img src="<?php echo e(asset('/frontend/images/logo.png')); ?>" class="logo" alt="Digiclinic">
          </a>
          <a href="index.html" class="d-lg-none d-md-block">
            <img src="<?php echo e(asset('/frontend/images/logo.png')); ?>" class="logo" alt="Digiclinic">
          </a>
        </div>
        <!-- App brand ends -->

        <!-- App header actions starts -->
        <div class="header-actions">

          <!-- Search container starts -->
          <!-- <div class="search-container d-lg-block d-none mx-3">
            <input type="text" class="form-control" id="searchId" placeholder="Search">
            <i class="ri-search-line"></i>
          </div> -->
          <!-- Search container ends -->

          <!-- Header actions starts -->
          <div class="d-lg-flex d-none gap-2">

            <!-- Select country dropdown starts -->
            <!-- <div class="dropdown">
              <a class="dropdown-toggle header-icon" href="#!" role="button" data-bs-toggle="dropdown"
                aria-expanded="false">
                <img src="assets/images/flags/1x1/fr.svg" class="header-country-flag" alt="Bootstrap Dashboards">
              </a>
              <div class="dropdown-menu dropdown-menu-end dropdown-mini">
                <div class="country-container">
                  <a href="index.html" class="py-2">
                    <img src="assets/images/flags/1x1/us.svg" alt="Admin Panel">
                  </a>
                  <a href="index.html" class="py-2">
                    <img src="assets/images/flags/1x1/in.svg" alt="Admin Panels">
                  </a>
                  <a href="index.html" class="py-2">
                    <img src="assets/images/flags/1x1/br.svg" alt="Admin Dashboards">
                  </a>
                  <a href="index.html" class="py-2">
                    <img src="assets/images/flags/1x1/tr.svg" alt="Admin Templatess">
                  </a>
                  <a href="index.html" class="py-2">
                    <img src="assets/images/flags/1x1/gb.svg" alt="Google Admin">
                  </a>
                </div>
              </div>
            </div> -->
            <!-- Select country dropdown ends -->

            <!-- Notifications dropdown starts -->
        
            <!-- Notifications dropdown ends -->

            <!-- Notifications dropdown starts -->
          <div class="dropdown">
            <a class="dropdown-toggle header-icon" href="#!" role="button" data-bs-toggle="dropdown"
                aria-expanded="false">
              <?php if($user_role_id == 9): ?>
              <?php
                          $nbre_ostock=DB::table('tbl_products')
                                    ->where('stock',0)
                                    ->count();

                          $nbre_lstock=DB::table('tbl_products')
                                    ->where('stock','<=',5)
                                    ->where('stock','!=',0)
                                    ->count();
              ?>
                <span
                        class="position-absolute top-0 start-5 translate-middle badge rounded-pill bg-danger"><?php echo e($nbre_ostock + $nbre_lstock); ?></span>
              <?php ?>
              <?php endif; ?>
                <i class="ri-alarm-warning-line"></i>

              </a>
              <div class="dropdown-menu dropdown-menu-end dropdown-300">


                <h5 class="fw-semibold px-3 py-2 text-primary">Alerts</h5>



                <!-- Scroll starts -->
                <div class="scroll300">

                  <!-- Alert list starts -->
                  <div class="p-3">

                  <?php
                        $low_stock=DB::table('tbl_products')
                                    ->where('stock','<=',5)
                                    ->where('stock','!=',0)
                                    ->get();
                  ?>

                  <?php $__currentLoopData = $low_stock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_lstok): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="d-flex py-2">
                      <div class="icon-box md bg-info rounded-circle me-3">
                         <img style="width: 50px;" src="<?php echo e(URL::asset($v_lstok->product_image)); ?>" alt="<?php echo e($v_lstok->product_name); ?>">
                      </div>
                      <div class="m-0">
                        <h6 class="mb-1 fw-semibold"><?php echo e($v_lstok->product_name); ?></h6>
                        <p class="mb-1">
                          Prix : <?php echo e($v_lstok->product_price); ?> F
                        </p>
                        <p style="color:red" class="small m-0 opacity-50">Stock : <?php echo e($v_lstok->stock); ?></p>
                      </div>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php ?>


                  </div>
                  <!-- Alert list ends -->

                </div>
                <!-- Scroll ends -->

                <!-- View all button starts -->
                <div class="d-grid m-3">
                  <a href="<?php echo e(URL::to('etat-stock')); ?>" class="btn btn-primary">Imprimer l'état stock</a>
                </div>
                <!-- View all button ends -->

              </div>
            </div>
            <!-- Notifications dropdown ends -->

            <!-- Messages dropdown starts -->
            
          </div>
          <!-- Header actions ends -->

          <!-- Header user settings starts -->
          <div class="dropdown ms-2">
            <a id="userSettings" class="dropdown-toggle d-flex align-items-center" href="#!" role="button"
              data-bs-toggle="dropdown" aria-expanded="false">
              <div class="avatar-box">JB<span class="status busy"></span></div>
            </a>
            <div class="dropdown-menu dropdown-menu-end shadow-lg">
              <div class="px-3 py-2">
                <span class="small"><?php echo e(Session::get('role')); ?></span>
                <h6 class="m-0"><?php echo e(Session::get('prenom')); ?> <?php echo e(Session::get('nom')); ?></h6>
              </div>
              <div class="mx-3 my-2 d-grid">
                <a href="<?php echo e(URL::to('logout')); ?>" class="btn btn-danger">Logout</a>
              </div>
            </div>
          </div>
          <!-- Header user settings ends -->

        </div>
        <!-- App header actions ends -->

      </div>
      <!-- App header ends -->

      <!-- Main container starts -->
      <div class="main-container">

        <!-- Sidebar wrapper starts -->
        <nav id="sidebar" class="sidebar-wrapper">
        <?php
        $email=Session::get('email');
        $user=DB::table('personnel')
              ->where('email',$email)
              ->first();
        ?>

          <!-- Sidebar profile starts -->
          <div class="sidebar-profile">
            <?php if($user->sexe == 'F'): ?>
            <img src="<?php echo e(asset('frontend/F.png')); ?>" class="img-shadow img-3x me-3 rounded-5" alt="Hospital Admin Templates">
            <?php else: ?>
            <img src="<?php echo e(asset('frontend/M.png')); ?>" class="img-shadow img-3x me-3 rounded-5" alt="Hospital Admin Templates">
            <?php endif; ?>
            <div class="m-0">
              <h5 class="mb-1 profile-name text-nowrap text-truncate"><?php echo e(Session::get('nom')); ?> <?php echo e(Session::get('prenom')); ?></h5>
              <p class="m-0 small profile-name text-nowrap text-truncate"><?php echo e($user->specialite); ?></p>
            </div>
          </div>
          <!-- Sidebar profile ends -->

          <!-- Sidebar menu starts -->
          <div class="sidebarMenuScroll">
            <ul class="sidebar-menu">
              <?php if($user_role_id == 0): ?>
              <li class="active current-page">
                <a href="<?php echo e(URL::to('/dashboard')); ?>">
                  <i class="ri-home-6-line"></i>
                  <span class="menu-text">Mon tableau de bord</span>
                </a>
              </li>
               <li class="treeview">
                <a href="#!">
                  <i class="ri-stethoscope-line"></i>
                  <span class="menu-text"><?php echo e(Session::get('role')); ?></span>
                </a>
                <ul class="treeview-menu">
                  <li>
                    <a href="<?php echo e(URL::to('prises-en-charges')); ?>">Prises en charges</a>
                  </li>
                </ul>
              </li>

              <?php elseif($user_role_id == 1): ?>
              <li class="active current-page">
                <a href="<?php echo e(URL::to('/dashboard')); ?>">
                  <i class="ri-home-6-line"></i>
                  <span class="menu-text">Mon tableau de bord</span>
                </a>
              </li>
              <li class="treeview">
                <a href="#!">
                  <i class="ri-money-dollar-circle-line"></i>
                  <span class="menu-text"><?php echo e(Session::get('role')); ?> </span>
                </a>
                <ul class="treeview-menu">
                  <li>
                    <a href="<?php echo e(URL::to('caisse-consultations')); ?>">Caisses consultations</a>
                  </li>
                  <li>
                    <a href="<?php echo e(URL::to('caisse-hospitalisations')); ?>">Caisses hospitalisations</a>
                  </li>
                  <li>
                    <a href="<?php echo e(URL::to('caisse-analyses')); ?>">Caisses Analyses</a>
                </li>

                </ul>
              </li>

              <li class="treeview">
                <a href="#!">
                  <i class="ri-dossier-line"></i>
                  <span class="menu-text">Pharmacie</span>
                </a>
                <ul class="treeview-menu">
                  <li>
                    <a href="<?php echo e(URL::to('/les-ventes')); ?>">Ventes à Caisse</a>
                  </li>
                  <li>
                    <a href="<?php echo e(URL::to('all-category')); ?>">Produits en Pharmacie</a>
                  </li>

                  <li>
                    <a href="<?php echo e(URL::to('approvisionnement')); ?>">Appro Pharmacie</a>
                  </li>

                </ul>
              </li>
              <?php elseif($user_role_id == 2 || $user_role_id == 3 || $user_role_id == 5 || $user_role_id == 6 || $user_role_id == 7 || $user_role_id == 8 ): ?>
              
              <li class="treeview">
                <a href="#!">
                  <i class="ri-stethoscope-line"></i>
                  <span class="menu-text"><?php echo e(Session::get('role')); ?></span>
                </a>
                <ul class="treeview-menu">
                  <li>
                    <a href="<?php echo e(URL::to('consultations')); ?>">Consultations</a>
                    
                  </li>
                </ul>
              </li>

<?php elseif($user_role_id == 4): ?>
              <li class="treeview">
                <a href="#!">
                  <i class="ri-microscope-line"></i>
                  <span class="menu-text"><?php echo e(Session::get('role')); ?></span>
                </a>
                <ul class="treeview-menu">
                  <li>
                  <a href="<?php echo e(URL::to('gestion-analyses')); ?>">Analyses Générales</a>
                    <a href="<?php echo e(URL::to('consultations')); ?>">Analyses internes</a>
                    <a href="#">Stock </a>
                  </li>
                </ul>
              </li>

              <?php elseif($user_role_id == 9): ?>
              <li class="active current-page">
                <a href="<?php echo e(URL::to('/dashboard')); ?>">
                  <i class="ri-home-6-line"></i>
                  <span class="menu-text">Mon tableau de bord</span>
                </a>
              </li>
              <li class="treeview">
                <a href="#!">
                  <i class="ri-dossier-line"></i>
                  <span class="menu-text"><?php echo e(Session::get('role')); ?></span>
                </a>
                <ul class="treeview-menu">
                  <li>
                    <a href="<?php echo e(URL::to('/les-ventes')); ?>">Ventes à Caisse</a>
                  </li>
                  <li>
                    <a href="<?php echo e(URL::to('all-category')); ?>">Produits en Pharmacie</a>
                  </li>

                  <li>
                    <a href="<?php echo e(URL::to('approvisionnement')); ?>">Appro Pharmacie</a>
                  </li>

                </ul>
              </li>
              <?php else: ?>

              <!-- Admin sidebar -->
              <!-- Admin sidebar -->
              <!-- Admin sidebar -->

              <li class="active current-page">
                <a href="<?php echo e(URL::to('/dashboard')); ?>">
                  <i class="ri-home-6-line"></i>
                  <span class="menu-text">Espace de l'hopital</span>
                </a>
              </li>
              <li>
                <a href="dashboard2.html">
                  <i class="ri-microscope-line fs-4"></i>
                  <span class="menu-text">Espace labo</span>
                </a>
              </li>
              <li class="">
                <a href="#!">
                  <i class="ri-stethoscope-line"></i>
                  <span class="menu-text">Espace Médecins</span>
                </a>
                
              </li>
            
              <li class="treeview">
                <a href="#!">
                  <i class="ri-heart-pulse-line"></i>
                  <span class="menu-text">Patients</span>
                </a>
                <ul class="treeview-menu">
                  <li>
                    <a href="<?php echo e(route('patient.repertoire')); ?>">Répertoire des patients</a>
                  </li>
                  
                  </ul>
              </li>
              <li class="treeview">
                <a href="#!">
                  <i class="ri-nurse-line"></i>
                  <span class="menu-text">Personnel</span>
                </a>
                <ul class="treeview-menu">
                  <li>
                    <a href="<?php echo e(route('personnel.index')); ?>">Liste du Peronnel</a>
                  </li>
                  <li>
                    <a href="<?php echo e(route('personnel.create')); ?>">Ajouter </a>
                  </li>
                  </ul>
              </li>
              <li class="treeview">
                <a href="#!">
                  <i class="ri-building-2-line"></i>
                  <span class="menu-text">Services</span>
                </a>
                <ul class="treeview-menu">
                  <li>
                    <a href="<?php echo e(route('services.index')); ?>">Répertoire des services</a>
                  </li>
                  <li>
                    <a href="<?php echo e(route('services.create')); ?>">Créer un nouveau service</a>
                  </li>

                </ul>
              </li>
               <li class="treeview">
                <a href="#!">
                  <i class="ri-hotel-bed-line"></i>
                  <span class="menu-text">Chambres</span>
                </a>
                <ul class="treeview-menu">
                  
                  <li>
                    <a href="<?php echo e(route('room.index')); ?>">Chambres par départements</a>
                  </li>
                  <li>
                    <a href="<?php echo e(route('allotted-room')); ?>">Chambres occupées</a>
                  </li>
                  <li>
                    <a href="available-rooms.html">Chambre disponible</a>
                  </li>
                  <li>
                    <a href="book-room.html">Book Room</a>
                  </li>
                  <li>
                    <a href="<?php echo e(route('room.create')); ?>">Ajout chambres</a>
                  </li>
                  <li>
                    <a href="edit-room.html">Edit Room</a>
                  </li>
                </ul>
              </li>
              <li class="treeview">
                <a href="#!">
                  <i class="ri-building-2-line"></i>
                  <span class="menu-text">Espace entités</span>
                </a>
                <ul class="treeview-menu">
                  <li>
                    <a href="<?php echo e(route('entities.add')); ?>">Créer une entité</a>
                  </li>
                  <li>
                    <a href="<?php echo e(route('entities.index')); ?>">Entités disponibles</a>
                  </li>

                </ul>
              </li>
               <li class="treeview">
                <a href="#!">
                  <i class="ri-building-2-line"></i>
                  <span class="menu-text">Espace centres</span>
                </a>
                <ul class="treeview-menu">
                  <li>
                    <a href="<?php echo e(route('centers.add')); ?>">Créer un centre</a>
                  </li>
                  <li>
                    <a href="<?php echo e(route('centers.index')); ?>">Centres disponibles</a>
                  </li>

                </ul>
              </li>
              <li class="treeview">
                <a href="#!">
                  <i class="ri-login-circle-line"></i>
                  <span class="menu-text">Comptes utilsateurs</span>
                </a>
                <ul class="treeview-menu">

                  <li>
                    <a href="<?php echo e(route('create.user')); ?>">Créer un nouveau compte</a>
                  </li>
                 <li>
                    <a href="reset-password.html">Réinitialiser un mot de passe</a>
                  </li>
                </ul>
              </li>





              <!-- Accueil sidebar -->
              <!-- Accueil sidebar -->


              

              
              


              <!-- Doctor sidebar -->
              <!-- Doctor sidebar -->
              <!-- Doctor sidebar -->
              <!-- Doctor sidebar -->
              <!-- Doctor sidebar -->


              
              

              <!-- General sidebar -->
              <!-- General sidebar -->
              <!-- General sidebar -->
              <!-- General sidebar -->
              <!-- General sidebar -->
              <!-- General sidebar -->

              
              <?php endif; ?>



                </ul>
          </div>
          <!-- Sidebar menu ends -->

          <!-- Sidebar contact starts -->
          <div class="sidebar-contact">
            <p class="fw-light mb-1 text-nowrap text-truncate">Numéro Support</p>
            <h5 class="m-0 lh-1 text-nowrap text-truncate">+229 90006005</h5>
            <i class="ri-phone-line"></i>
          </div>
          <!-- Sidebar contact ends -->

        </nav>
        <!-- Sidebar wrapper ends -->

        <!-- App container starts -->
        <div class="app-container">

          <!-- App hero header starts -->
          <div class="app-hero-header d-flex align-items-center">

            <!-- Breadcrumb starts -->
            <ol class="breadcrumb">
              <li class="breadcrumb-item">
                <i class="ri-home-8-line lh-1 pe-3 me-3 border-end"></i>
                <a href="index.html">Home</a>
              </li>
              <li class="breadcrumb-item text-primary" aria-current="page"><a href="<?php echo e(URL::to('/dashboard')); ?>">
                Tableau de bord</a>
              </li>
            </ol>
            <!-- Breadcrumb ends -->

            <!-- Sales stats starts -->
            <!-- <div class="ms-auto d-lg-flex d-none flex-row">
              <div class="d-flex flex-row gap-1 day-sorting">
                <button class="btn btn-sm btn-primary">Today</button>
                <button class="btn btn-sm">7d</button>
                <button class="btn btn-sm">2w</button>
                <button class="btn btn-sm">1m</button>
                <button class="btn btn-sm">3m</button>
                <button class="btn btn-sm">6m</button>
                <button class="btn btn-sm">1y</button>
              </div>
            </div> -->
            <!-- Sales stats ends -->

          </div>
          <!-- App Hero header ends -->

          <!-- App body starts -->


                <?php echo $__env->yieldContent('user_content'); ?>
                <?php echo $__env->yieldContent('admin'); ?>
                <?php echo $__env->yieldContent('admin_content'); ?>
                <?php echo $__env->yieldContent('staff content'); ?>
                <?php echo $__env->yieldContent('add staff content'); ?>
                <?php echo $__env->yieldContent('service content'); ?>
                <?php echo $__env->yieldContent('add service content'); ?>


          <!-- App body ends -->

          <!-- App footer starts -->
          <div class="app-footer bg-white">
            <span>© DigiClinic 2024</span>
          </div>
          <!-- App footer ends -->

        </div>
        <!-- App container ends -->

      </div>
      <!-- Main container ends -->

    </div>
<script src="<?php echo e(asset('frontend/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/app.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/optionadd.js')); ?>"></script>

<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?php echo e(asset('frontend/js/bootstrap.bundle.min.js')); ?>"></script>

<!-- *************
************ Vendor Js Files *************
************* -->


<!-- Overlay Scroll JS -->
<script src="<?php echo e(asset('frontend/vendor/overlay-scroll/jquery.overlayScrollbars.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/vendor/overlay-scroll/custom-scrollbar.js')); ?>"></script>

<!-- Apex Charts -->
<script src="<?php echo e(asset('frontend/vendor/apex/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/vendor/apex/custom/graphs/area.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/vendor/apex/custom/graphs/line.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/vendor/apex/custom/graphs/bar.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/vendor/apex/custom/graphs/column-area.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/vendor/apex/custom/graphs/candlestick.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/vendor/apex/custom/graphs/heatmap.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/vendor/apex/custom/patients/medicalExpenses.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/vendor/apex/custom/patients/healthActivity.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/vendor/apex/custom/patients/insuranceClaims.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/vendor/apex/custom/patients/sparklines.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/vendor/apex/custom/department/department-list.js')); ?>"> </script>
<script src="<?php echo e(asset('frontend/vendor/apex/custom/department/employees.js')); ?>"> </script>
<script src="<?php echo e(asset('frontend/vendor/apex/custom/graphs/pie.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/vendor/apex/custom/rooms/admissions.js')); ?>"></script>



<!-- Calendar JS -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script src="<?php echo e(asset('frontend/vendor/calendar/js/main.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/vendor/calendar/custom/daygrid-calendar.js')); ?>"></script>

<!-- Date Range JS -->
<script src="<?php echo e(asset('frontend/vendor/daterange/daterange.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/vendor/daterange/custom-daterange.js')); ?>"></script>

<!-- Vector Maps -->
<script src="<?php echo e(asset('frontend/vendor/jvectormap/jquery-jvectormap-2.0.5.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/vendor/jvectormap/world-mill-en.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/vendor/jvectormap/gdp-data.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/vendor/jvectormap/us_aea.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/vendor/jvectormap/usa.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/vendor/jvectormap/continents-mill.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/vendor/jvectormap/custom/world-map-markers2.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/vendor/jvectormap/custom/map-usa.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/vendor/jvectormap/custom/map-usa2.js')); ?>"></script>

<!-- Morris Graphs -->
<script src="<?php echo e(asset('frontend/vendor/morris/raphael-min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/vendor/morris/morris.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/vendor/morris/custom/area.j')); ?>s"></script>
<script src="<?php echo e(asset('frontend/vendor/morris/custom/barColors.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/vendor/morris/custom/dayData.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/vendor/morris/custom/donutColors.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/vendor/morris/custom/donutFormatter.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/vendor/morris/custom/morrisBar.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/vendor/morris/custom/negativeValues.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/vendor/morris/custom/stackedBar.js')); ?>"></script>

<!-- Custom JS files -->
<script src="<?php echo e(asset('frontend/js/custom.js')); ?>"></script>

<script src="<?php echo e(asset('frontend/vendor/dropzone/dropzone.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/vendor/quill/quill.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/vendor/quill/custom.js')); ?>"></script>


<!-- DataTables.js -->
<link href="https://cdn.datatables.net/2.1.5/css/dataTables.dataTables.min.css" rel="stylesheet">
<?php echo $__env->yieldContent('Datatable'); ?>
<script src="https://cdn.datatables.net/2.1.5/js/dataTables.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/slim-select/1.23.0/slimselect.min.js"></script>
<?php echo $__env->yieldPushContent('js'); ?>
<?php echo $__env->yieldPushContent('ajax'); ?>

<script>
var quill = new Quill("#quill_editor", {
  theme: "snow",
});
let tb = document.querySelector('#tb')

    function block (para = null) {
        if(para){
            para.preventDefault();
        }else {
            return true;
        }
    }

let edit = document.querySelector('.ql-editor');
let texte = document.querySelector('#textar')
edit.addEventListener('keyup', () => {
        texte.innerHTML = edit.innerHTML
})



var quill1 = new Quill("#quill_editor1", {
  theme: "snow",
});
let tb1 = document.querySelector('#tb1')

    function block (para = null) {
        if(para){
            para.preventDefault();
        }else {
            return true;
        }
    }

let edit1 = document.querySelector('.ql-editor1');
let texte1 = document.querySelector('#textar1')
edit1.addEventListener('keyup', () => {
        texte1.innerHTML = edit1.innerHTML
})
</script>

</body>

</html><?php /**PATH C:\Users\ADMIN\Downloads\digiclinic\resources\views/layout.blade.php ENDPATH**/ ?>