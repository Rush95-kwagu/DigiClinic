<?php $__env->startSection('user_content'); ?>
<?php $__env->startSection('title'); ?>
Espace du personnel
<?php $__env->stopSection(); ?>
<?php  
 $user_role_id=Session::get('user_role_id');
 $user_id=Session::get('user_id');
 $centre_id=Session::get('centre_id');
?>

            <!-- App body starts -->
          <div class="app-body">

            <!-- Row starts -->
            <div class="row gx-3">
              <div class="col-sm-12">
                <div class="card">
                  <div class="card-header d-flex align-items-center justify-content-between">
                    <h5 class="card-title">Liste du personnel</h5>
                    <a href="<?php echo e(route('personnel.create')); ?>" class="btn btn-primary ms-auto">Ajouter</a>
                  </div>
                  <div class="card-body">

                    <!-- Table starts -->
                    <div class="table-responsive">
                      <table id="basicExample" class="table m-0 align-middle">
                        <thead>
                          <tr>
                            <th>#</th>
                            <th>Nom</th>
                            <th>Désignation</th>
                            <th>Téléphone</th>
                            <th>Email</th>
                            <th>Date de Naissance</th>
                            <th>Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                        <?php
                          $personnels = DB::table('personnel')
                                      ->get();
                          $services = DB::table('services')
                                      ->get();
                        ?>
                            <?php $__currentLoopData = $personnels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personnel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                          <tr>
                            <td><?php echo e($personnel->id); ?></td>
                            
                            <td>
                             
                                  <?php if($personnel->sexe == 'F'): ?>
                                  <img src="<?php echo e(asset('frontend/F.png')); ?>" class="img-shadow img-2x rounded-5 me-1"
                                    alt="Doctors Admin Template">
                                  <?php else: ?>
                                   <img src="<?php echo e(asset('frontend/M.png')); ?>" class="img-shadow img-2x rounded-5 me-1"
                                    alt="Doctors Admin Template">
                                  <?php endif; ?>
                             <?php echo e($personnel->nom); ?> <?php echo e($personnel->prenom); ?>


                            </td>
                            <td><?php echo e($personnel->qualification); ?></td>
                            <td>
                              <?php echo e($personnel->telephone); ?>

                            </td>
                            <td><?php echo e($personnel->email); ?></td>
                            <td><?php echo e($personnel->birthdate); ?></td>
                            <td>
                              <div class="d-inline-flex gap-1">
                                <button class="btn btn-outline-danger btn-sm" data-bs-toggle="modal"
                                  data-bs-target="#delRow">
                                  <i class="ri-delete-bin-line"></i>
                                </button>
                                <a href="<?php echo e(route('personnel.edit',$personnel->id)); ?>" class="btn btn-outline-success btn-sm"
                                  data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Edit Staff Member">
                                  <i class="ri-edit-box-line"></i>
                                </a>
                              </div>
                            </td>
                          </tr>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                    </div>
                    <!-- Table ends -->

                    <!-- Modal Delete Row -->
                    <div class="modal fade" id="delRow" tabindex="-1" aria-labelledby="delRowLabel" aria-hidden="true">
                      <div class="modal-dialog modal-sm">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="delRowLabel">
                              Confirm
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                          </div>
                          <div class="modal-body">
                            Are you sure you want to delete the staff member?
                          </div>
                          <div class="modal-footer">
                            <div class="d-flex justify-content-end gap-2">
                              <button class="btn btn-outline-secondary" data-bs-dismiss="modal"
                                aria-label="Close">No</button>
                              <button class="btn btn-danger" data-bs-dismiss="modal" aria-label="Close">Yes</button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                  </div>
                </div>
              </div>
            </div>
            <!-- Row ends -->

          </div>
          <!-- App body ends -->

        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP ELITEBOOK X360\Downloads\digiclinic\resources\views/staff/staff.blade.php ENDPATH**/ ?>